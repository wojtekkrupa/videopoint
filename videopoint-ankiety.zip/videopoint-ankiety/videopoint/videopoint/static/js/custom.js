$( document ).ready(function() {

    $( "#surveyEditButton" ).click(function() {

      $('#surveyEditRow').toggle();

    });

    $( "#userBasicDataEditButton" ).click(function() {

      $('#userBasicDataEditRow').toggle();

    });

    $( "#userPasswordEditButton" ).click(function() {

      $('#userPasswordEditRow').toggle();

    });

});